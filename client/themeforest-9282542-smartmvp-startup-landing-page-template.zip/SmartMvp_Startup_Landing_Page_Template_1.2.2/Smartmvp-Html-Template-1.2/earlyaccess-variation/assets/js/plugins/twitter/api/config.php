<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'mhjI2MgV7nfAN25ZbDXEcWS9Y');
    define('CONSUMER_SECRET', 'm1kouwneKUvjlMjCyMJBZf5NPySmcFJDcSTMEeuTrneLYbIUPT');

    // User Access Token
    define('ACCESS_TOKEN', '1922782302-vAL3zSMJj3e5FbnjtZdNxTEuTlaYYk9H9GbFFvJ');
    define('ACCESS_SECRET', 'gSvDHDfVJag5F4568OwGa4vHykTMCgSMtUoxmQ33MApxX');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));