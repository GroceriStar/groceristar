'use strict';

module.exports = function(Item) {

};
