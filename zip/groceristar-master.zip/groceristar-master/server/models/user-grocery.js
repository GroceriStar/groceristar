'use strict';

module.exports = function(Usergrocery) {

};
