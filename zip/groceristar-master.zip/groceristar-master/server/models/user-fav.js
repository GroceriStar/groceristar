'use strict';

module.exports = function(UserFav) {

	// UserFav.listFavorites = function(userId, cb){

	// 	User.findById(userId, {}, function(model){
	// 		console.log(model.favs);
	// 	});

	// }
	// //:todo add remote method for this functionality

};
