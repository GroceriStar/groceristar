module.exports = {
  RAVEN_KEY: 'https://6c8ba2737aae4d81908677e4dba9be3f:26c83aa1a38a42cdbf0beea41a82cacf@sentry.io/231031'
};
