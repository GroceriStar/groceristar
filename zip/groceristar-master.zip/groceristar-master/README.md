# GroceriStar Server

# Note!
We're moving from Loopback into GraphQL Framework. So don't have a lot of progress here.

# Documentation Website
https://groceristar.github.io/documentation/

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/76fe5b42fcc04691a06381ed1d26171b)](https://www.codacy.com/app/atherdon/loopback-fb-login?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=atherdon/loopback-fb-login&amp;utm_campaign=Badge_Grade)

<img src="https://sentry-brand.storage.googleapis.com/sentry-logo-black.png" alt="Drawing" width="150" height="40"/>

[![Waffle.io - Issues in progress](https://badge.waffle.io/GroceriStar/groceristar.png?label=in%20progress&title=In%20Progress)](http://waffle.io/GroceriStar/groceristar)


- [Local install](/install.md#local)
- [Heroku deploy](/install.md#heroku)
- [Credits](/credits.md)
- [Contributing](/CONTRIBUTING.md)
- [FLOW](/FLOW.md)
- [Static Pages](/PAGES.md)
- [DB Schema dev mode](https://sqldbm.com/Project/MySQL/Share/v1Tcp4mXo3Gy1tmiICeBJg)

