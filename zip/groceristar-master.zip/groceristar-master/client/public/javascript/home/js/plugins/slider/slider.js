$(document).ready(function() {
    
    "use strict";
    
    /*----------------------------------------------------*/
    /*  FULL SLIDER SCRIPT
    /*----------------------------------------------------*/
    $("#slides").superslides({
        play: 6000,
        animation: "fade",
        pagination: false
    });
        


});
